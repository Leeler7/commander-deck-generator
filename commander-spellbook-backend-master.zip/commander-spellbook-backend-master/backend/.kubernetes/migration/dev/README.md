# Dev deployment

Currently there is no separate database for the dev deployment, so there is no migration task for dev. If we add a dev database, then we will add the kustomization file for the migration task into this directory.