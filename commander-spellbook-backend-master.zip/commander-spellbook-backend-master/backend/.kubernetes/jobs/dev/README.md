# Dev Jobs

Currently jobs only run with the production deployment. If we add jobs to the dev deployment, we would add a kustomization file in this directory.