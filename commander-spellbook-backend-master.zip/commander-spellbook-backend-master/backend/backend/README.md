# Django Backend Project
This folder contains the configuration for a Django backend powered by the Django REST framework.
