django.jQuery(function() {
    django.jQuery('form').dirty({preventLeaving: true});
});
