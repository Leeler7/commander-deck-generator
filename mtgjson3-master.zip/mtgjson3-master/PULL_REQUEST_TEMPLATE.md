<!--
Make sure to update the "changelog.json" file in the "/web" folder as well!
Use version style X.Y.Z (X = incompatible/breaking change | Y = new set | Z = fix)
Don't forget to add "updatedSetFiles" once you touch any set.json files in "/json".
-->
